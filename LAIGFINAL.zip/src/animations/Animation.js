/**
 * Animation
 * @constructor
 */
function Animation(scene, id, span, type) {
    this.scene = scene;
    this.id = id;
    this.span = span;
    this.type = type;
};


Animation.prototype.apply = function () {
};

Animation.prototype.update = function () {
};

